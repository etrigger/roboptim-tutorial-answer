Shared CMake submodule
======================

This repository is meant to be used as a submodule for any project
from CNRS LAAS/HPP or JRL.

It factorizes CMake mechanisms to provide a uniform look'n feel for
all packages.


Please see the documentation on the [wiki] for more information.

[wiki]: http://github.com/jrl-umi3218/jrl-cmakemodules/wiki
